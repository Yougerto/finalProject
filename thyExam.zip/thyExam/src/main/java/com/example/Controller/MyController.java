package com.example.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

//import com.example.ExchangeRate.ExchangeRateRepository;


@Controller
public class MyController {
	
//	@Autowired
//	private ExchangeRateRepository exchangeRateRepository;
//
//		
//		
//	    public MyController(ExchangeRateRepository exchangeRateRepository) {
//	        this.exchangeRateRepository = exchangeRateRepository;
//	    }
	@RequestMapping("/index")
	public String index() {
		return "index";
	}
	

	
	@PostMapping("/processExchangeRates")
    public String processExchangeRates(@RequestParam String exchangeRateData) {
        // 在此處進行後端處理，例如將數據存儲到數據庫、進行計算等
        // 注意：ExchangeRate是一個自定義的Java類，用於表示匯率數據
        // 在此示例中，我們僅將數據打印到控制台
		
		
        System.out.println("Received exchange rate data:");
        System.out.println(exchangeRateData);

        // 處理完成後，可以返回一個重定向到 /exchange-rate 的頁面，用戶將回到匯率數據頁面
        return "index";
    }

	
}
